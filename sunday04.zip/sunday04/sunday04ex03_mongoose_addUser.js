// sunday03ex06_adduser.js
var http = require('http');
var path = require('path');
var express = require('express');
var app = express();
var router = express.Router();
var static = require('serve-static');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var expressSession = require('express-session');
var mongoose = require('mongoose');

app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use('/public', static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(expressSession({
    secret: 'my key',
    resave: true,
    saveUninitialized: true
}));

var db;
var UserSchema;
var UserModel;

function connectDB(){
    var dburl = "mongodb://localhost:27017/local";

    console.log('데이터 베이스 연결을 시도합니다.');
    mongoose.Promise = global.Promise;
    mongoose.connect(dburl);
    db = mongoose.connection;
    db.on('error', console.error.bind(console, 'MongoDB connection error:'));
    db.on('open', ()=>{
        console.log('데이터베이스에 연결되었습니다. :%s', dburl);
        // 스키마와 모델을 준비 한다.
        UserSchema = mongoose.Schema({
            id: String,
            name: String,
            password: String
        });
        //console.log('UserSchema 정의함 >>>', UserSchema);

        UserModel = mongoose.model('users', UserSchema);
        //console.log('UserModel 정의함.', UserModel);
    });
    //연결이 끊어졌을 때 5초후 재 연결
    db.on('disconnected', ()=>{
        console.log('연결이 끊어졌습니다. 5초 후 다시 연결합니다.');
        setTimeout(connectDB(), 5000);
    });
};

function addUser(db, userData, callback){
    console.log('addUser 함수 호출 >>>', userData);
    var user = new UserModel(userData);
    user.save(function(err){
        if(err){
            callback(err,null);
            return;
        }
        console.log('사용자 정보 입력 완료');
        callback(null,user);
    });
};

router.route('/process/adduser').post((req,res)=>{
    console.log('/proecess/adduser 요청 받음...');
    var paramId = req.body.id;
    var paramPwd = req.body.password;
    var paramName = req.body.name;
    var userData = {
        id: paramId,
        namd: paramName,
        password: paramPwd
    };

    if(db){
        addUser(db, userData, (err, user)=>{
            if(err){
                res.end('error');
                return;
            }else{
                res.end('success');
            }
        });
    }else{
        res.end();
        console.log('DB Connection Error');
    }
});




app.use('/', router);
var server = http.createServer(app);
server.listen(app.get('port'), (err)=>{
    if(err) throw err;
    console.log(`Server Running... Port:${app.get('port')}`);
    connectDB();
});