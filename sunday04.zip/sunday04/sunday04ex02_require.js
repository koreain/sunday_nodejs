var user = require('./sunday04ex01_exports');


var user1 = user.getUser();
var usergroup1 = user.group;



console.log(user1.name);
console.log(usergroup1.name);

function showUser(){
    return `name:${user.getUser().name}, group:${user.group.name}`;
};

console.log('사용자정보: %s', showUser());

