console.log('npm npm npm');

exports.getUser = ()=>{
    return {id: 'test01', name: 'shiny'};
};

exports.group = {id:'group01', name:'brother'};