//sunday04ex04_counter.js

const http = require('http');
var express = require('express');
var cors = require('cors')
var router = express.Router();
var app = express();
var static = require('serve-static');
var path = require('path');

app.set('port',3000);
app.use(cors());
app.use('/public', static(path.join(__dirname, 'public')));

var cnt = 0;
router.route('/count').get((req,res)=>{
    console.log('/count 요청 들어옴');
        cnt++;
});

router.route('/count_result').get(function(req,res){
    var size = Number(req.query.size);
    if(size < cnt){
        var response = {
            "count":cnt
        };
        res.end(JSON.stringify(response));
    }else{
        res.end();
    }
});




app.use('/', router);
var server = http.createServer(app);
server.listen(app.get('port'), ()=>{
    console.log(`Server running ... http://localhost:${app.get('port')}`);
});


