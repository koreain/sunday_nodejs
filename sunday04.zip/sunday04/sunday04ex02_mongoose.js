const http = require('http');
const express = require('express');
var app = express();
var path = require('path');
var mongoose = require('mongoose');

var database;
var UserSchema;
var UserModel;

app.set('port', process.env.PORT||3000);
app.set('view engine', 'ejs');
app.set('veiws', path.join(__dirname, '/views'));

function connectDB(){
    var dburl = "mongodb://localhost:27017/local";

    console.log('데이터 베이스 연결을 시도합니다.');
    mongoose.Promise = global.Promise;
    mongoose.connect(dburl);
    db = mongoose.connection;
    db.on('error', console.error.bind(console, 'MongoDB connection error:'));
    db.on('open', ()=>{
        console.log('데이터베이스에 연결되었습니다. :%s', dburl);
        // 스키마와 모델을 준비 한다.
        UserSchema = mongoose.Schema({
            id: String,
            name: String,
            password: String
        });
        //console.log('UserSchema 정의함 >>>', UserSchema);

        UserModel = mongoose.model('users', UserSchema);
        //console.log('UserModel 정의함.', UserModel);
    });
    //연결이 끊어졌을 때 5초후 재 연결
    db.on('disconnected', ()=>{
        console.log('연결이 끊어졌습니다. 5초 후 다시 연결합니다.');
        setInterval(connectDB, 5000);
    });
};






// //Define a schema
// var Schema = mongoose.Schema;
// var UserSchema = new Schema({
//   a_string: String,
//   a_date: Date
// });
// var UserModel = mongoose.model('UserModel', UserSchema );






var server = http.createServer(app);
server.listen(app.get('port'), (err)=>{
    if(err) throw err;
    console.log(`Server Running... Port:${app.get('port')}`);
    connectDB();
});