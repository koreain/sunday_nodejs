var http = require('http');
var express = require('express');
var socketio = require('socket.io');
var app =express();

app.set('port', process.env.PORT||3000);
var server = http.createServer(app);
server.listen(app.get('port'), ()=>{
    console.log(`Server is running.... http://localhost:${app.get('port')}`);
});

var io = socketio.listen(server);

io.sockets.on('connection', function(socket){
    console.log('connection.........');
    socket.on('message', function(data){
        console.log('message 받음...', data);
        socket.emit('message', data); //echo 메세지 에코처리
    });
});