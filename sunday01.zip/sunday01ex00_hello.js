// sunday01ex00_hello.js

console.log('NodeJS Programming');

let sayHello = (name) => {
    console.log(`${name}님 안녕하세요 :)`);
}

sayHello('송미');