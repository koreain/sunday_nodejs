// sunday01ex_02_require.js

// 상대경로
var calc = require('./sunday01ex02_exports');

console.log(calc.minus(5,2));